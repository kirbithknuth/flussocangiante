
import React, { useRef, useEffect } from 'react';
import { StoryBlockData } from '../types';
import StoryBlock from './StoryBlock';

interface StoryDisplayProps {
  blocks: StoryBlockData[];
}

const StoryDisplay: React.FC<StoryDisplayProps> = ({ blocks }) => {
  const endOfMessagesRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [blocks]);

  return (
    <div className="flex-grow overflow-y-auto bg-gray-800 p-4 md:p-6 rounded-lg shadow-inner space-y-4">
      {blocks.map((block) => (
        <StoryBlock key={block.id} block={block} />
      ))}
      <div ref={endOfMessagesRef} />
    </div>
  );
};

export default StoryDisplay;
