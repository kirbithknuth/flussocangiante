import React from 'react';
import { Choice } from '../types';

interface ChoiceSelectorProps {
  choices: Choice[];
  onChoiceSelected: (nextNodeId: string) => void;
  isDisabled?: boolean;
}

const ChoiceSelector: React.FC<ChoiceSelectorProps> = ({ choices, onChoiceSelected, isDisabled = false }) => {
  if (!choices || choices.length === 0) {
    return null;
  }

  return (
    <div className="mt-4 p-3 bg-gray-800 rounded-lg shadow-md flex flex-col items-center space-y-3">
      {choices.map((choice, index) => (
        <button
          key={index}
          onClick={() => onChoiceSelected(choice.nextNodeId)}
          disabled={isDisabled}
          className="w-full md:w-3/4 lg:w-1/2 bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6 rounded-md transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-opacity-75 disabled:opacity-50 disabled:cursor-not-allowed"
          aria-label={`Scegli: ${choice.text}`}
        >
          {choice.text}
        </button>
      ))}
    </div>
  );
};

export default ChoiceSelector;
