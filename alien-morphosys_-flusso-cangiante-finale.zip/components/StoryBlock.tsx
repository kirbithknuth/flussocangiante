import React from 'react';
import { StoryBlockData, StoryBlockType } from '../types';

interface StoryBlockProps {
  block: StoryBlockData;
}

const StoryBlock: React.FC<StoryBlockProps> = ({ block }) => {
  const alignment = 'items-start'; // Tutti i blocchi narrativi/sistema/errore allineati a sinistra/inizio
  
  let bgColor = 'bg-slate-700'; // Default per NARRATIVE
  let textColor = 'text-white';
  let textAlign = 'text-left';

  switch (block.type) {
    case StoryBlockType.SYSTEM:
      bgColor = 'bg-blue-700';
      break;
    case StoryBlockType.ERROR:
      bgColor = 'bg-red-700';
      break;
    case StoryBlockType.NARRATIVE:
    default:
      // bgColor and textAlign already set
      break;
  }

  return (
    <div className={`flex flex-col ${alignment} w-full`}>
      <div 
        className={`p-4 rounded-xl shadow-md max-w-3xl mx-auto w-full md:w-11/12 lg:w-3/4 break-words ${bgColor} ${textColor} ${textAlign}`}
        aria-label={`${block.type} message`}
      >
        <p className="whitespace-pre-wrap">{block.text}</p>
        <p className="text-xs opacity-70 mt-2">
          {block.timestamp.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
    </div>
  );
};

export default StoryBlock;
