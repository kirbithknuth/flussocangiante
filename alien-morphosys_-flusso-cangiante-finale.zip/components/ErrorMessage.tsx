
import React from 'react';

interface ErrorMessageProps {
  title: string;
  message: string;
}

const ErrorMessage: React.FC<ErrorMessageProps> = ({ title, message }) => {
  return (
    <div className="bg-red-700 border border-red-900 text-white px-4 py-3 rounded-lg relative shadow-md" role="alert">
      <strong className="font-bold block sm:inline">{title}</strong>
      <span className="block sm:inline mt-1 sm:mt-0 sm:ml-2">{message}</span>
    </div>
  );
};

export default ErrorMessage;
