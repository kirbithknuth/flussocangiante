// import { GoogleGenAI, Chat, GenerateContentResponse, HarmCategory, HarmBlockThreshold } from "@google/genai";

// const API_KEY = process.env.API_KEY;
// let genAIInstance: GoogleGenAI | null = null;
// let initError: string | null = null;

// if (API_KEY) {
//   try {
//     genAIInstance = new GoogleGenAI({ apiKey: API_KEY });
//   } catch (e) {
//     console.error("Failed to initialize GoogleGenAI:", e);
//     initError = (e as Error).message || "Errore sconosciuto durante l'inizializzazione di GoogleGenAI.";
//     genAIInstance = null; 
//   }
// } else {
//   console.error("API_KEY environment variable is not set.");
//   initError = "API_KEY environment variable is not set.";
// }

// export const getGenAIInitializationError = (): string | null => {
//   return initError;
// };

// export const isGenAIInitialized = (): boolean => {
//   return genAIInstance !== null && initError === null;
// };

// export const startChatSession = (systemInstruction: string): Chat | null => {
//   if (!isGenAIInitialized() || !genAIInstance) {
//     console.error("Gemini AI SDK non inizializzato correttamente.");
//     return null;
//   }
//   try {
//     const chat = genAIInstance.chats.create({
//       model: 'gemini-2.5-flash-preview-04-17',
//       config: {
//         systemInstruction: systemInstruction,
//         safetySettings: [
//           { category: HarmCategory.HARM_CATEGORY_HARASSMENT, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
//           { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
//           { category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
//           { category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
//         ],
//       },
//     });
//     return chat;
//   } catch (error) {
//     console.error("Errore durante l'avvio della sessione di chat:", error);
//     initError = (error as Error).message || "Errore sconosciuto durante l'avvio della chat.";
//     return null;
//   }
// };

// export const sendMessageToChat = async (chat: Chat, messageText: string): Promise<GenerateContentResponse> => {
//   if (!isGenAIInitialized()) {
//     throw new Error("Gemini AI SDK non inizializzato correttamente.");
//   }
//   try {
//     const result = await chat.sendMessage({ message: messageText });
//     return result;
//   } catch (error) {
//     console.error("Errore durante l'invio del messaggio:", error);
//     throw error; 
//   }
// };

// Per ora, il file viene mantenuto ma il suo contenuto è commentato
// per indicare che non è attivamente utilizzato.
// Potrebbe essere rimosso completamente in una pulizia futura.
export {}; // Aggiungi un export vuoto per rendere il file un modulo ed evitare errori di compilazione.
